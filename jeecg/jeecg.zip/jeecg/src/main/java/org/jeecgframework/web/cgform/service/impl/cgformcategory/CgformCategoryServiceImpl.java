package org.jeecgframework.web.cgform.service.impl.cgformcategory;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.jeecgframework.core.common.service.impl.CommonServiceImpl;
import org.jeecgframework.web.cgform.service.cgformcategory.CgformCategoryServiceI;

@Service("cgformCategoryService")
@Transactional
public class CgformCategoryServiceImpl extends CommonServiceImpl implements CgformCategoryServiceI {
	
}