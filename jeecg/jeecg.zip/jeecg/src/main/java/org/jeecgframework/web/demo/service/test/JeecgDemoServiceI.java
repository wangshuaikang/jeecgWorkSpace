package org.jeecgframework.web.demo.service.test;

import org.jeecgframework.core.common.service.CommonService;


public interface JeecgDemoServiceI extends CommonService{

}
