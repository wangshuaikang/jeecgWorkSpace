package org.jeecgframework.web.cgform.service.cgformcategory;

import org.jeecgframework.core.common.service.CommonService;

public interface CgformCategoryServiceI extends CommonService{

}
