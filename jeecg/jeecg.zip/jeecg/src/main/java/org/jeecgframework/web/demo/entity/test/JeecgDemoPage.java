package org.jeecgframework.web.demo.entity.test;

import java.util.List;

/**
 * Created by zzl on 2015/7/1.
 */
public class JeecgDemoPage {
    private List<JeecgDemo> demos;

    public List<JeecgDemo> getDemos() {
        return demos;
    }

    public void setDemos(List<JeecgDemo> demos) {
        this.demos = demos;
    }
}
