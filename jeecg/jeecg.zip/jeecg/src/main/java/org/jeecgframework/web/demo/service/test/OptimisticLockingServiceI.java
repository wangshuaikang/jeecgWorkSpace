package org.jeecgframework.web.demo.service.test;

import org.jeecgframework.core.common.service.CommonService;

public interface OptimisticLockingServiceI extends CommonService{
	public void  dd ();
}
