package org.jeecgframework.web.demo.service.test;

import org.jeecgframework.core.common.service.CommonService;

/**
 * <li>类型名称：
 * <li>说明：物料Bom业务接口类
 * <li>创建人： 温俊
 * <li>创建日期：2013-8-12
 * <li>修改人： 
 * <li>修改日期：
 */
public interface JeecgMatterBomServiceI extends CommonService {

}
