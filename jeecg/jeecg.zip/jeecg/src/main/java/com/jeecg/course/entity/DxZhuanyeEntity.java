package com.jeecg.course.entity;

import java.math.BigDecimal;
import java.util.Date;
import java.lang.String;
import java.lang.Double;
import java.lang.Integer;
import java.math.BigDecimal;
import javax.xml.soap.Text;
import java.sql.Blob;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.annotations.GenericGenerator;
import javax.persistence.SequenceGenerator;
import org.jeecgframework.poi.excel.annotation.Excel;

/**   
 * @Title: Entity
 * @Description: 专业
 * @author onlineGenerator
 * @date 2016-11-06 12:45:54
 * @version V1.0   
 *
 */
@Entity
@Table(name = "dx_zhuanye", schema = "")
@SuppressWarnings("serial")
public class DxZhuanyeEntity implements java.io.Serializable {
	/**主键*/
	private Integer id;
	/**专业名称*/
	@Excel(name="专业名称")
	private String zhuanyeName;
	
	/**
	 *方法: 取得java.lang.Integer
	 *@return: java.lang.Integer  主键
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name ="ID",nullable=false,length=20)
	public Integer getId(){
		return this.id;
	}

	/**
	 *方法: 设置java.lang.Integer
	 *@param: java.lang.Integer  主键
	 */
	public void setId(Integer id){
		this.id = id;
	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  专业名称
	 */
	@Column(name ="ZHUANYE_NAME",nullable=false,length=50)
	public String getZhuanyeName(){
		return this.zhuanyeName;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  专业名称
	 */
	public void setZhuanyeName(String zhuanyeName){
		this.zhuanyeName = zhuanyeName;
	}
}
