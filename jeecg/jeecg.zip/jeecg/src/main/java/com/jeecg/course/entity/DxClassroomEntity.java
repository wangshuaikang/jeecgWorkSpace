package com.jeecg.course.entity;

import java.math.BigDecimal;
import java.util.Date;
import java.lang.String;
import java.lang.Double;
import java.lang.Integer;
import java.math.BigDecimal;
import javax.xml.soap.Text;
import java.sql.Blob;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.annotations.GenericGenerator;
import javax.persistence.SequenceGenerator;
import org.jeecgframework.poi.excel.annotation.Excel;

/**   
 * @Title: Entity
 * @Description: 教室
 * @author onlineGenerator
 * @date 2016-11-05 15:25:02
 * @version V1.0   
 *
 */
@Entity
@Table(name = "dx_classroom", schema = "")
@SuppressWarnings("serial")
public class DxClassroomEntity implements java.io.Serializable {
	/**主键*/
	private String id;
	/**名称*/
	@Excel(name="名称")
	private String name;
	/**可容纳人数*/
	@Excel(name="可容纳人数")
	private Integer capacity;
	/**所在位置*/
	@Excel(name="所在位置")
	private String place;
	
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  主键
	 */
	@Id
	@GeneratedValue(generator = "paymentableGenerator")
	@GenericGenerator(name = "paymentableGenerator", strategy = "uuid")
	@Column(name ="ID",nullable=false,length=36)
	public String getId(){
		return this.id;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  主键
	 */
	public void setId(String id){
		this.id = id;
	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  名称
	 */
	@Column(name ="NAME",nullable=false,length=50)
	public String getName(){
		return this.name;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  名称
	 */
	public void setName(String name){
		this.name = name;
	}
	/**
	 *方法: 取得java.lang.Integer
	 *@return: java.lang.Integer  可容纳人数
	 */
	@Column(name ="CAPACITY",nullable=false,length=32)
	public Integer getCapacity(){
		return this.capacity;
	}

	/**
	 *方法: 设置java.lang.Integer
	 *@param: java.lang.Integer  可容纳人数
	 */
	public void setCapacity(Integer capacity){
		this.capacity = capacity;
	}
	/**
	 *方法: 取得java.lang.String
	 *@return: java.lang.String  所在位置
	 */
	@Column(name ="PLACE",nullable=true,length=32)
	public String getPlace(){
		return this.place;
	}

	/**
	 *方法: 设置java.lang.String
	 *@param: java.lang.String  所在位置
	 */
	public void setPlace(String place){
		this.place = place;
	}
}
