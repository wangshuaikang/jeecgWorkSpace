package com.jeecg.course.service;
import com.jeecg.course.entity.DxClassroomEntity;
import org.jeecgframework.core.common.service.CommonService;

import java.io.Serializable;

public interface DxClassroomServiceI extends CommonService{
	
 	public void delete(DxClassroomEntity entity) throws Exception;
 	
 	public Serializable save(DxClassroomEntity entity) throws Exception;
 	
 	public void saveOrUpdate(DxClassroomEntity entity) throws Exception;
 	
}
