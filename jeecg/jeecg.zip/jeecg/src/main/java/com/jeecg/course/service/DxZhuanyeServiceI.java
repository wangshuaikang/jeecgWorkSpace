package com.jeecg.course.service;
import com.jeecg.course.entity.DxZhuanyeEntity;
import org.jeecgframework.core.common.service.CommonService;

import java.io.Serializable;

public interface DxZhuanyeServiceI extends CommonService{
	
 	public void delete(DxZhuanyeEntity entity) throws Exception;
 	
 	public Serializable save(DxZhuanyeEntity entity) throws Exception;
 	
 	public void saveOrUpdate(DxZhuanyeEntity entity) throws Exception;
 	
}
